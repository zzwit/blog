<?php
return [
    'type'       => 'redis',
    'host'       => '127.0.0.1',
    'port'       => 6379,
    'password'   => '',
    'select'     => 0,
    'timeout'    => 0,
    'expire'     => 0,
    'persistent' => false,
    'prefix'     => 'zyxs:',
    'serialize'  => true,

    // 测试服
    // 'type'       => 'redis',
    // 'host'       => '120.24.98.102',
    // 'port'       => 6379,
    // 'password'   => '0RusTL16FAJbBWmhSMZwxrQIGqgCO5PH',
    // 'select'     => 0,
    // 'timeout'    => 0,
    // 'expire'     => 0,
    // 'persistent' => false,
    // 'prefix'     => 'duoduo:',
    // 'serialize'  => true,

    // 'type'     => 'redis',
    // 'host'     => '120.24.98.102',
    // 'port'     => 6379,
    // 'password' => '0RusTL16FAJbBWmhSMZwxrQIGqgCO5PH',
];