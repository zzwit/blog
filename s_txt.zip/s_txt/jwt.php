<?php
# 登加密key 不能修改
return [
    'key'=>'7GegFcwUiHd42yKu1Yfm9jNzQRlvCDEk'
];