<?php
// Changed password for user apm_system
// PASSWORD apm_system = Unv5s8VzGafBJzpRCUV0

// Changed password for user kibana_system
// PASSWORD kibana_system = bVGeZTvcKvW1uVpELnCF

// Changed password for user kibana
// PASSWORD kibana = bVGeZTvcKvW1uVpELnCF

// Changed password for user logstash_system
// PASSWORD logstash_system = 9Esiaqvikik6RXvcd618

// Changed password for user beats_system
// PASSWORD beats_system = Y33Z8y6YUDrqTVUExMNJ

// Changed password for user remote_monitoring_user
// PASSWORD remote_monitoring_user = 7aDnWYJWnjMN63lKGLdA

// Changed password for user elastic
// PASSWORD elastic = oyLO0IepGQrbGT0CqoVK
return [
    'host'=>[
        'http://elastic:hfQpHv6FLrOgztB9sYlReZKGIMWyD8UC@127.0.0.1:9200'
    ]
];