<?php
// 阿里云配置
return [
    'AccessKeyID'     => 'LTAI4GFtHef2zipdMcVy2C7J', 
    'AccessKeySecret' => 'HtDPnpnKH9tmuNQUEKN2jn8SAv88sA',
    'Bucket'          => 'jizhangduoduo',
    'Endpoint'        => 'oss-cn-guangzhou.aliyuncs.com',
    'SignName'        => "卓越小说",
    'TemplateCode'    => "SMS_208265122",
];