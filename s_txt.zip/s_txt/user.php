<?php
// 用户相关配置
return [
    // 登录有效时间
    'login_expire' => 86400*180,
    // 登录key名前缀
    'login_prefix' => 'loginAuth:',
    // 登录token类型 normal or jwt
    // normal 是 token + redis形式
    'token_type'   => 'jwt',
    // 不用登录的接口，全部小写
    'ignore'=>[
        // 整个模块
        'module'     => [
            // 'h5'
        ],
        // 整个控制器
        'controller' => [
            // 'index/xxx',
            'index/sync',
            'index/chan',
            'index/app',
            'index/search',
        ],
        // 单个方法
        'action'     => [
            'index/base/miss',
            'index/user/login',
            'index/user/sms',
            'index/pay/xsynotify',
            'index/ad/list',
            

            'index/book/list',
            'index/book/search',
            'index/book/recommend',
            'index/book/detail',
            'index/book/chapter',
            'index/book/shelfrecommend',
        ],
    ],
];